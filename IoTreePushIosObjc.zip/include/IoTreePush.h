//
//  IoTreePush.h
//  ioTreePushIosObjcSample
//
//  Created by Sunghan Park on 2022/07/26.
//

#import <UIKit/UIKit.h>
#import "IoTreePushDelegate.h"
@import UserNotifications;

NS_ASSUME_NONNULL_BEGIN

@interface IoTreePush : NSObject

+ (void)initializeWithApplication:(UIApplication *)application appKey:(NSString *_Nonnull)appKey delegate:(id<IoTreePushDelegate>)delegate feedbackBaseUrl:(NSString *_Nullable)baseUrl;
+ (void)mapToken:(NSData *_Nonnull)deviceToken;
+ (void)registerTokenWithUserId:(NSString *)userId groups:(NSSet *)groups callback: (void (^)(NSString *_Nullable token, NSError *_Nullable error))callback;
+ (void)unregisterTokenWithCallback:(void (^)(NSError *_Nullable error))callback;
+ (void)subscribeTopic:(NSString *)topic withCallback:(void (^)(NSError *_Nullable error))callback;
+ (void)unsubscribeTopic:(NSString *)topic withCallback:(void (^)(NSError *_Nullable error))callback;
+ (void)handleDeliveredNotifications;
+ (void)populateNotificationContent:(UNMutableNotificationContent *)content withContentHandler:(void (^)(UNNotificationContent *_Nonnull))contentHandler;

@end

NS_ASSUME_NONNULL_END
