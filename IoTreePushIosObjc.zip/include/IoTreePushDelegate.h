//
//  IoTreePushDelegate.h
//  ioTreePushIosObjcSample
//
//  Created by Sunghan Park on 2022/07/26.
//

#import <Foundation/Foundation.h>

@protocol IoTreePushDelegate

- (void)onMessageWillPresent:(NSDictionary *_Nonnull)data withId:(NSString *_Nonnull)pushId;
- (void)onMessageDidReceive:(NSDictionary *_Nonnull)data withId:(NSString *_Nonnull)pushId;

@end
